// Expense Tracker Application
class ExpenseTracker {
    constructor() {
        this.expenses = this.loadExpenses();
        this.charts = {};
        this.categoryIcons = {
            fuel: '⛽',
            food: '🍔',
            travel: '✈️',
            shopping: '🛒',
            bills: '💳',
            entertainment: '🎬',
            health: '🏥',
            education: '📚',
            other: '📦'
        };
        this.categoryColors = {
            fuel: '#f59e0b',
            food: '#10b981',
            travel: '#3b82f6',
            shopping: '#8b5cf6',
            bills: '#ef4444',
            entertainment: '#ec4899',
            health: '#06b6d4',
            education: '#6366f1',
            other: '#64748b'
        };
        this.init();
    }

    init() {
        // Set today's date as default
        document.getElementById('date').valueAsDate = new Date();

        // Event listeners
        document.getElementById('expenseForm').addEventListener('submit', (e) => this.handleAddExpense(e));
        document.getElementById('filterCategory').addEventListener('change', () => this.renderExpenses());
        document.getElementById('filterDateFrom').addEventListener('change', () => this.renderExpenses());
        document.getElementById('filterDateTo').addEventListener('change', () => this.renderExpenses());
        document.getElementById('clearFilters').addEventListener('click', () => this.clearFilters());

        // Handle window resize for charts
        let resizeTimer;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                if (this.charts.weekly && this.charts.monthly && this.charts.category) {
                    this.charts.weekly.resize();
                    this.charts.monthly.resize();
                    this.charts.category.resize();
                }
            }, 250);
        });

        // Handle orientation change
        window.addEventListener('orientationchange', () => {
            setTimeout(() => {
                if (this.charts.weekly && this.charts.monthly && this.charts.category) {
                    this.charts.weekly.resize();
                    this.charts.monthly.resize();
                    this.charts.category.resize();
                }
            }, 500);
        });

        // Initial render
        this.renderExpenses();
        this.updateAnalytics();
        this.initCharts();
    }

    loadExpenses() {
        const stored = localStorage.getItem('expenses');
        return stored ? JSON.parse(stored) : [];
    }

    saveExpenses() {
        localStorage.setItem('expenses', JSON.stringify(this.expenses));
    }

    handleAddExpense(e) {
        e.preventDefault();
        
        const expense = {
            id: Date.now().toString(),
            amount: parseFloat(document.getElementById('amount').value),
            category: document.getElementById('category').value,
            description: document.getElementById('description').value || 'No description',
            date: document.getElementById('date').value
        };

        this.expenses.push(expense);
        this.expenses.sort((a, b) => new Date(b.date) - new Date(a.date));
        this.saveExpenses();

        // Reset form
        document.getElementById('expenseForm').reset();
        document.getElementById('date').valueAsDate = new Date();

        // Update UI
        this.renderExpenses();
        this.updateAnalytics();
        this.updateCharts();
    }

    deleteExpense(id) {
        if (confirm('Are you sure you want to delete this expense?')) {
            this.expenses = this.expenses.filter(exp => exp.id !== id);
            this.saveExpenses();
            this.renderExpenses();
            this.updateAnalytics();
            this.updateCharts();
        }
    }

    getFilteredExpenses() {
        const categoryFilter = document.getElementById('filterCategory').value;
        const dateFrom = document.getElementById('filterDateFrom').value;
        const dateTo = document.getElementById('filterDateTo').value;

        return this.expenses.filter(expense => {
            const categoryMatch = !categoryFilter || expense.category === categoryFilter;
            const dateMatch = (!dateFrom || expense.date >= dateFrom) && 
                             (!dateTo || expense.date <= dateTo);
            return categoryMatch && dateMatch;
        });
    }

    renderExpenses() {
        const filteredExpenses = this.getFilteredExpenses();
        const tbody = document.getElementById('expensesTableBody');
        
        if (filteredExpenses.length === 0) {
            tbody.innerHTML = '<tr class="no-data"><td colspan="5">No expenses found. Try adjusting your filters.</td></tr>';
            document.getElementById('tableTotal').innerHTML = '<strong>₹0</strong>';
            return;
        }

        tbody.innerHTML = filteredExpenses.map(expense => {
            const date = new Date(expense.date);
            const formattedDate = date.toLocaleDateString('en-IN', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            });

            return `
                <tr>
                    <td>${formattedDate}</td>
                    <td><span class="category-badge">${this.categoryIcons[expense.category]} ${expense.category.charAt(0).toUpperCase() + expense.category.slice(1)}</span></td>
                    <td>${expense.description}</td>
                    <td>₹${expense.amount.toFixed(2)}</td>
                    <td><button class="btn-danger" onclick="tracker.deleteExpense('${expense.id}')">Delete</button></td>
                </tr>
            `;
        }).join('');

        // Calculate and display total
        const total = filteredExpenses.reduce((sum, exp) => sum + exp.amount, 0);
        document.getElementById('tableTotal').innerHTML = `<strong>₹${total.toFixed(2)}</strong>`;
    }

    clearFilters() {
        document.getElementById('filterCategory').value = '';
        document.getElementById('filterDateFrom').value = '';
        document.getElementById('filterDateTo').value = '';
        this.renderExpenses();
    }

    getCurrentWeekExpenses() {
        const now = new Date();
        const startOfWeek = new Date(now);
        startOfWeek.setDate(now.getDate() - now.getDay());
        startOfWeek.setHours(0, 0, 0, 0);

        return this.expenses.filter(exp => {
            const expDate = new Date(exp.date);
            return expDate >= startOfWeek && expDate <= now;
        });
    }

    getCurrentMonthExpenses() {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

        return this.expenses.filter(exp => {
            const expDate = new Date(exp.date);
            return expDate >= startOfMonth && expDate <= now;
        });
    }

    getWeekData() {
        const weekExpenses = this.getCurrentWeekExpenses();
        const weekData = {};
        const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        
        // Initialize all days with 0
        days.forEach(day => weekData[day] = 0);

        weekExpenses.forEach(exp => {
            const date = new Date(exp.date);
            const dayName = days[date.getDay()];
            weekData[dayName] = (weekData[dayName] || 0) + exp.amount;
        });

        return { labels: days, data: days.map(day => weekData[day]) };
    }

    getMonthData() {
        const monthExpenses = this.getCurrentMonthExpenses();
        const now = new Date();
        const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
        const monthData = {};

        // Initialize all days with 0
        for (let i = 1; i <= daysInMonth; i++) {
            monthData[i] = 0;
        }

        monthExpenses.forEach(exp => {
            const date = new Date(exp.date);
            const day = date.getDate();
            monthData[day] = (monthData[day] || 0) + exp.amount;
        });

        const labels = Array.from({ length: daysInMonth }, (_, i) => (i + 1).toString());
        const data = labels.map(day => monthData[parseInt(day)]);

        return { labels, data };
    }

    getCategoryData() {
        const monthExpenses = this.getCurrentMonthExpenses();
        const categoryData = {};

        monthExpenses.forEach(exp => {
            categoryData[exp.category] = (categoryData[exp.category] || 0) + exp.amount;
        });

        const categories = Object.keys(categoryData);
        return {
            labels: categories.map(cat => `${this.categoryIcons[cat]} ${cat.charAt(0).toUpperCase() + cat.slice(1)}`),
            data: categories.map(cat => categoryData[cat]),
            colors: categories.map(cat => this.categoryColors[cat] || '#64748b')
        };
    }

    updateAnalytics() {
        const weekExpenses = this.getCurrentWeekExpenses();
        const monthExpenses = this.getCurrentMonthExpenses();
        
        const weekTotal = weekExpenses.reduce((sum, exp) => sum + exp.amount, 0);
        const monthTotal = monthExpenses.reduce((sum, exp) => sum + exp.amount, 0);
        const total = this.expenses.reduce((sum, exp) => sum + exp.amount, 0);
        
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const daysPassed = Math.floor((now - startOfMonth) / (1000 * 60 * 60 * 24)) + 1;
        const avgDaily = daysPassed > 0 ? monthTotal / daysPassed : 0;

        document.getElementById('weekTotal').textContent = `₹${weekTotal.toFixed(2)}`;
        document.getElementById('monthTotal').textContent = `₹${monthTotal.toFixed(2)}`;
        document.getElementById('totalExpenses').textContent = `₹${total.toFixed(2)}`;
        document.getElementById('avgDaily').textContent = `₹${avgDaily.toFixed(2)}`;
    }

    initCharts() {
        // Weekly Chart
        const weeklyCtx = document.getElementById('weeklyChart').getContext('2d');
        const weekData = this.getWeekData();
        this.charts.weekly = new Chart(weeklyCtx, {
            type: 'line',
            data: {
                labels: weekData.labels,
                datasets: [{
                    label: 'Daily Expenses (₹)',
                    data: weekData.data,
                    borderColor: '#4f46e5',
                    backgroundColor: 'rgba(79, 70, 229, 0.2)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    pointBackgroundColor: '#4f46e5',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                resizeDelay: 100,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(26, 32, 44, 0.95)',
                        titleColor: '#ffffff',
                        bodyColor: '#a0a0a0',
                        borderColor: '#4f46e5',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#a0a0a0',
                            font: {
                                size: window.innerWidth < 480 ? 10 : 12
                            }
                        },
                        grid: {
                            color: '#2d3748'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#a0a0a0',
                            font: {
                                size: window.innerWidth < 480 ? 10 : 12
                            },
                            callback: function(value) {
                                return '₹' + value.toFixed(0);
                            }
                        },
                        grid: {
                            color: '#2d3748'
                        }
                    }
                }
            }
        });

        // Monthly Chart
        const monthlyCtx = document.getElementById('monthlyChart').getContext('2d');
        const monthData = this.getMonthData();
        this.charts.monthly = new Chart(monthlyCtx, {
            type: 'bar',
            data: {
                labels: monthData.labels,
                datasets: [{
                    label: 'Daily Expenses (₹)',
                    data: monthData.data,
                    backgroundColor: 'rgba(79, 70, 229, 0.7)',
                    borderColor: '#4f46e5',
                    borderWidth: 2,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                resizeDelay: 100,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(26, 32, 44, 0.95)',
                        titleColor: '#ffffff',
                        bodyColor: '#a0a0a0',
                        borderColor: '#4f46e5',
                        borderWidth: 1,
                        padding: 12,
                        displayColors: false
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#a0a0a0',
                            font: {
                                size: window.innerWidth < 480 ? 10 : 12
                            },
                            maxRotation: window.innerWidth < 480 ? 45 : 0
                        },
                        grid: {
                            color: '#2d3748',
                            display: false
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: '#a0a0a0',
                            font: {
                                size: window.innerWidth < 480 ? 10 : 12
                            },
                            callback: function(value) {
                                return '₹' + value.toFixed(0);
                            }
                        },
                        grid: {
                            color: '#2d3748'
                        }
                    }
                }
            }
        });

        // Category Chart
        const categoryCtx = document.getElementById('categoryChart').getContext('2d');
        const categoryData = this.getCategoryData();
        this.charts.category = new Chart(categoryCtx, {
            type: 'doughnut',
            data: {
                labels: categoryData.labels,
                datasets: [{
                    data: categoryData.data,
                    backgroundColor: categoryData.colors,
                    borderWidth: 2,
                    borderColor: '#1a202c'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                resizeDelay: 100,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#a0a0a0',
                            padding: window.innerWidth < 480 ? 10 : 15,
                            font: {
                                size: window.innerWidth < 480 ? 10 : 12
                            },
                            usePointStyle: true,
                            boxWidth: window.innerWidth < 480 ? 8 : 12
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(26, 32, 44, 0.95)',
                        titleColor: '#ffffff',
                        bodyColor: '#a0a0a0',
                        borderColor: '#4f46e5',
                        borderWidth: 1,
                        padding: 12
                    }
                }
            }
        });
    }

    updateCharts() {
        // Update Weekly Chart
        const weekData = this.getWeekData();
        this.charts.weekly.data.labels = weekData.labels;
        this.charts.weekly.data.datasets[0].data = weekData.data;
        this.charts.weekly.update();

        // Update Monthly Chart
        const monthData = this.getMonthData();
        this.charts.monthly.data.labels = monthData.labels;
        this.charts.monthly.data.datasets[0].data = monthData.data;
        this.charts.monthly.update();

        // Update Category Chart
        const categoryData = this.getCategoryData();
        this.charts.category.data.labels = categoryData.labels;
        this.charts.category.data.datasets[0].data = categoryData.data;
        this.charts.category.data.datasets[0].backgroundColor = categoryData.colors;
        this.charts.category.update();
    }
}

// Initialize the expense tracker when the page loads
let tracker;
document.addEventListener('DOMContentLoaded', () => {
    tracker = new ExpenseTracker();
});

