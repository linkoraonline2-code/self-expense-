# 💰 Expense Tracker

A beautiful, modern expense tracker web application to help you track your daily expenses by category.

## Features

- ✅ **Track Expenses by Category**: Add expenses with categories like Fuel, Food, Travel, Shopping, Bills, Entertainment, Health, Education, and Others
- 📊 **Analytics Dashboard**: View key statistics including:
  - This Month's total expenses
  - This Week's total expenses
  - Total expenses
  - Average daily expenses
- 📈 **Interactive Charts**:
  - **Weekly Expenses**: Line chart showing daily expenses for the current week
  - **Monthly Expenses**: Bar chart showing daily expenses for the current month
  - **Category Breakdown**: Doughnut chart showing expense distribution by category
- 📋 **Expense Table**: View all expenses in a sortable table with:
  - Filter by category
  - Filter by date range
  - Delete expenses
  - Total calculation for filtered results
- 💾 **Local Storage**: All your data is automatically saved in your browser's local storage

## How to Use

1. **Open the Application**: Simply open `index.html` in your web browser
2. **Add an Expense**:
   - Enter the amount
   - Select a category
   - Optionally add a description
   - Select the date (defaults to today)
   - Click "Add Expense"
3. **View Analytics**: Check the Analytics section to see your spending patterns
4. **Filter Expenses**: Use the filters above the table to view specific expenses
5. **Delete Expenses**: Click the "Delete" button next to any expense to remove it

## Categories Available

- ⛽ Fuel
- 🍔 Food
- ✈️ Travel
- 🛒 Shopping
- 💳 Bills
- 🎬 Entertainment
- 🏥 Health
- 📚 Education
- 📦 Other

## Technology Stack

- **HTML5**: Structure
- **CSS3**: Styling with modern gradients and animations
- **JavaScript (ES6+)**: Application logic
- **Chart.js**: Beautiful, interactive charts
- **LocalStorage API**: Data persistence

## Browser Compatibility

Works on all modern browsers (Chrome, Firefox, Safari, Edge).

## Notes

- All data is stored locally in your browser
- To backup your data, you can export it from the browser's developer console
- The application automatically calculates weekly and monthly statistics based on the current date

Enjoy tracking your expenses! 🎉

